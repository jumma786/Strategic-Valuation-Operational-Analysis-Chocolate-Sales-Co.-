# Power BI Dashboard — Rebuild Guidance

I can't open `.pbix` files in this environment, so I can't fix yours directly. Here's what to build instead. If your existing dashboard already does most of this, only act on the gaps.

---

## The brutal test

Open your current `.pbix` and ask: **what does this show that the Excel pivots don't?**

If the answer is "the same numbers, but with slicers" — you have a problem. A static pivot table beats a redundant dashboard. A dashboard earns its place by enabling **exploration the static pivots can't**: cross-filtering, drill-through, time intelligence, and dynamic comparisons.

---

## Required: 4 pages, in this order

### Page 1 — Executive Overview
Hiring managers spend 10 seconds here. It must answer "how is the business doing?" without clicking.

- **5 KPI cards across the top:** Total Revenue, Boxes Shipped, Avg Revenue/Box, Active Reps, Active Countries
- **Line chart:** Monthly revenue with reference line at the period average. The Feb dip should be visually obvious.
- **Bar chart:** Revenue by country, sorted descending
- **Donut or treemap:** Top 10 products by revenue (cap at 10; group the rest as "Other")
- **Single date slicer** at the top affecting all visuals

### Page 2 — Salesperson Performance
- **Bar chart:** All 25 reps, sorted by revenue, with a conditional-format color gradient
- **Scatter plot:** Revenue (Y) vs. Boxes Shipped (X) per rep — outliers visible immediately
- **Table:** Sales Person, Revenue, Boxes, Rev/Box, Rank, % of Total
- **Country slicer + Product slicer** so reviewers can filter to "best UK rep for premium SKUs"

### Page 3 — Country & Product Performance
- **Matrix visual:** Countries × Products with revenue values and conditional formatting (heat map)
- **Two bar charts side by side:** Revenue by country, Rev/Box by country (so the Canada pricing problem is visually obvious)
- **Top N filter** on products (default 10, slider to expand)

### Page 4 — Trend & Outlier Analysis
- **Line chart with trend line:** Monthly revenue with a 3-month rolling average overlay
- **Column chart:** Month-over-month % change, with positive/negative conditional formatting
- **Scatter plot:** Individual transactions with the 2-sigma outlier line drawn (matches Query 10 in the SQL file)
- **Table of outlier transactions** (rep, country, product, date, amount)

---

## Required DAX measures

Don't rely on implicit Power BI aggregations. Write these as explicit measures so the model is portable and the logic is documented.

```DAX
Total Revenue = SUM(data[Amount])

Total Boxes = SUM(data[Boxes Shipped])

Avg Revenue per Box =
DIVIDE([Total Revenue], [Total Boxes])

Revenue PY =
CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(data[Date]))

Revenue MoM % =
VAR PrevMonth =
    CALCULATE([Total Revenue], DATEADD(data[Date], -1, MONTH))
RETURN
    DIVIDE([Total Revenue] - PrevMonth, PrevMonth)

Revenue Running Total =
CALCULATE(
    [Total Revenue],
    FILTER(
        ALLSELECTED(data[Date]),
        data[Date] <= MAX(data[Date])
    )
)

Rev per Box vs Median =
VAR MedianRevPerBox =
    MEDIANX(VALUES(data[Country]), [Avg Revenue per Box])
RETURN
    [Avg Revenue per Box] - MedianRevPerBox

% of Total Revenue =
DIVIDE([Total Revenue], CALCULATE([Total Revenue], ALL(data)))
```

The `Rev per Box vs Median` measure is the one that surfaces the Canada problem visually — anywhere it's negative, the country is under-pricing the global benchmark.

---

## Design rules

- **One color accent.** Pick one (e.g., a deep brown to fit the chocolate theme). Use grayscale for everything else. Stop using Power BI's default rainbow palette.
- **Consistent currency formatting.** All money formatted as `$#,##0` with no decimals. Rev/box formatted as `$#,##0.00`.
- **Title every visual.** "Revenue by Country" beats an unlabeled bar chart.
- **No 3D charts. No pie charts beyond the donut on page 1.** They're harder to read than bar charts and scream "first dashboard."
- **Page-level filters at the top, not the side.** Mobile-friendly and easier to spot.

---

## Drill-through

Set up a drill-through page where right-clicking any country, product, or rep on the overview page opens a detail page filtered to that selection. This is the single biggest "wow" feature reviewers look for and is trivial to implement (right-click field → Add to drill-through).

---

## Cross-filter behavior

- Set the Country slicer to affect all visuals on every page (synced slicer)
- Set bar chart selections to cross-filter the matrix and tables on the same page
- Disable cross-filtering on KPI cards (otherwise clicking on a country also changes the headline KPIs, which is usually undesired)

---

## Publish to Power BI Service

If you have a free Power BI account, publish the report and include a **public web link** in your portfolio README. Hiring managers vastly prefer clicking a link to downloading a `.pbix`. About half won't bother to download.

---

## What NOT to do

- Don't include a "valuation" or "DCF" page. That work is in a separate project for a separate role type.
- Don't use the default Power BI sample colors and theme. Customize the theme JSON or pick one of the tasteful built-ins (avoid "Boutique").
- Don't put 15 visuals on one page. Density signals "I don't know what's important." 4–5 visuals per page is the right target.
- Don't include screenshots in the dashboard itself. The dashboard is the screenshot.

---

## Final check before you submit

Open the dashboard cold. Ask out loud: "If I were a sales director, what would I do tomorrow based on this?"

If you can't answer in one sentence, the dashboard is showing data instead of telling a story. Fix that before sending.

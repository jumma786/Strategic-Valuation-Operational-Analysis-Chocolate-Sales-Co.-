# Tootsie Roll Industries DCF — Methodology & Defense Notes

This document accompanies `Tootsie_Roll_DCF_Model.xlsx`. It explains the modeling choices and prepares you to defend them in an interview. Read this *before* opening the workbook.

---

## The Headline

**Base case DCF: ~$26.72/share. Current price: $42.10. Implied downside: -36%.**

Comparable companies analysis: ~$30.65/share base case (also below current price).

The DCF says Tootsie Roll is overvalued. **That's the model's view, not necessarily the right view.** Two things to know before you defend it:

1. The market is paying a premium that the DCF doesn't capture: defensive cash flow, brand quality, takeover speculation, and a scarcity premium for clean-balance-sheet small caps.
2. A buy-side or equity research interviewer will probe: "Why do you think you know better than the market?" The honest answer is: "I don't. I'm presenting the math. The reconciliation between intrinsic and trading value is the analyst's judgment call."

---

## What the Model Says

| Method | Low | Base | High |
|---|---|---|---|
| DCF (perpetuity growth) | $24.19 | $26.72 | $44.21 |
| Comparable Cos. EV/EBITDA | $24.55 | $30.65 | $34.06 |
| 52-week trading range | $30.12 | $42.10 (current) | $45.06 |

The bull case for the DCF (WACC 6%, g 3%) gets to $44 — close to the 52-week high. That's not coincidence: the market is pricing in something like a 6% discount rate and aggressive perpetual growth.

---

## Key Modeling Decisions (and how to defend them)

### 1. WACC = 7.9%, essentially equal to cost of equity

**Why:** Tootsie Roll has zero bank debt, so capital structure is 100% equity. The 7.9% comes from CAPM:
- Risk-free rate: 4.42% (10Y Treasury, FRED, Apr 30 2026)
- Beta: 0.45 (5Y monthly, confirms defensive consumer staple)
- Equity risk premium: 5.5% (Damodaran 2026 implied ERP)
- Size premium: 1.0% (CRSP 9th decile equivalent for $3B mid-cap)
- Cost of equity = 4.42% + 0.45 × 5.5% + 1.0% = **7.9%**

**Pushback you'll get:** "Why a size premium for a $3B company?" 
**Answer:** "Float is thin, dual-class structure restricts liquidity, and the company doesn't host earnings calls — analyst coverage is sparse. The size premium captures the illiquidity and lack of price discovery, not just market cap."

**Pushback:** "Beta of 0.45 looks low — are you sure?"
**Answer:** "Yes. CNBC and Yahoo Finance both report ~0.45 on a 5-year monthly basis. It's consistent with the defensive nature of confectionery — sales held up in 2008–09 and 2020 recessions. If I used a peer average beta (~0.7), my cost of equity would be ~8.7% and the DCF would drop to ~$24."

### 2. Terminal growth = 2.0%

**Why:** Long-run US inflation expectation; mature confectionery category with limited organic volume growth. Tootsie Roll's 2023–2025 organic revenue trend has been roughly flat — projecting any growth above inflation would be aggressive.

**Pushback:** "Couldn't they grow faster with international expansion?"
**Answer:** "They could, but the track record argues otherwise. The Spanish subsidiary has been loss-making for years and management is now reviewing strategic options for it. Mexico is a small contributor. The company's stated focus is the North American core, and management has not signaled any major international push."

### 3. Operating margin recovers from 13.8% to 16.0% by 2030

**Why:** The 10-K explicitly states cocoa and chocolate cost relief is expected in late 2026 and into 2027. Pre-cocoa-spike margins were ~16%. Modeling a 5-year glidepath back to that level is consistent with management's MD&A.

**Pushback:** "What if cocoa stays elevated?"
**Answer:** "That's the bear case. If margins stay at 13.8% terminal, the DCF drops to roughly $20/share. Cocoa futures suggest some normalization but it's a real risk."

### 4. CapEx is split: 5.5% of revenue near-term, 3.5% steady-state

**Why:** The 10-K discloses a $75–85M plant expansion over the next seven years, with most spending in 2026. That's why 2025 CapEx was $34M (up 90% vs. 2024). Front-loading the elevated CapEx and reverting to historical 3.5% steady-state is the correct treatment.

### 5. Net debt includes the multi-employer pension PV ($34M)

**Why:** Tootsie Roll participates in a multi-employer pension plan in "critical and declining status." The 10-K discloses a withdrawal liability with present value of $32.9M–$35.4M. This is real economic debt that any acquirer would have to assume. Excluding it would overstate equity value by ~$0.46/share.

**Pushback:** "Is this really debt? They're not planning to withdraw."
**Answer:** "It's a real economic liability that gets fully recognized in any takeout scenario or insolvency. SEC-style EV bridges include unfunded pension obligations as quasi-debt. The 10-K's risk factors flag it as a potential material adverse impact."

### 6. Family control discount is NOT applied

**Why:** I called this out explicitly on the README sheet rather than baking it in. Applying a discount inside the DCF compounds with the WACC's size/illiquidity premium. Better to let the user see the unadjusted DCF and apply discount judgment at the end.

**A buy-side analyst would probably haircut equity value 10–15%** for governance — meaning the *true* fair value (in their view) is closer to $23–$24/share, deepening the implied downside.

---

## The Three Things an Interviewer Will Probe Hardest

### Q: "Your DCF says the stock is 36% overvalued. Walk me through what would have to be true for the current $42 price to be justified."

**Answer:** "Three things, individually or in combination:
- WACC closer to 6% — meaning the market is willing to discount Tootsie Roll's cash flows at near-Treasury rates. Plausible given zero leverage and defensive cash flow.
- Terminal growth closer to 3% — implying confectionery can grow above inflation, which I think is aggressive but not crazy.
- Operating margin expansion to 18%+ — meaning cocoa relief flows through harder than I'm modeling.

Even with all three, my best-case bull DCF is ~$44. So the market is pricing in something close to that aggressive scenario. The question is whether you believe it."

### Q: "Why use the perpetuity growth method instead of an exit multiple?"

**Answer:** "Both have merit. I went with perpetuity growth because exit multiples in confectionery range from 10x (General Mills) to 19x (Mondelez). At a 14x exit, my DCF rises to ~$31/share — in line with the comps view. I built the comps section to triangulate. The perpetuity method forces me to be explicit about long-run economics rather than borrowing peer multiples that may themselves be inflated by a low-rate environment."

### Q: "What's the single biggest sensitivity?"

**Answer:** "Terminal margin assumption. If margin stays at 14% rather than recovering to 16%, the DCF drops about $4/share. WACC matters less — the company's cash position dampens WACC sensitivity because changing the discount rate doesn't change the $580M of net cash."

---

## What This Model Deliberately Doesn't Do

- **No segment-level forecast.** Tootsie Roll reports as a single segment. The 10-K provides limited geographic breakdown and no product-level disclosure.
- **No working capital schedule.** I use a simplified ΔNWC = 20% × ΔRevenue rule. A more rigorous model would project AR days, inventory days, AP days separately.
- **No three-statement integration.** No projected balance sheet or cash flow statement reconciliation. This is a "DCF-lite" appropriate for an interview prep / portfolio piece, not a full equity research model.
- **No M&A scenario.** Tootsie Roll is takeout-speculation candidate. A formal LBO analysis or strategic acquirer DCF is out of scope here.
- **No Monte Carlo.** A full sell-side model would simulate distributions of cocoa prices, FX, and revenue growth. Out of scope.

If asked, "what would you add next?" — say segment forecast, formal three-statement model, and Monte Carlo on commodity inputs.

---

## How to Use the Workbook

1. Open `Tootsie_Roll_DCF_Model.xlsx`.
2. Start with the **README** sheet (in-file documentation).
3. Review the **Summary** sheet for headline output.
4. **Assumptions** sheet — every blue cell can be flexed. Try changing terminal growth or operating margin to see live impact.
5. **Sensitivity** has a heatmap of WACC × terminal growth.
6. **Comps** triangulates against peer multiples.
7. **Football Field** visualizes the valuation range across methods.

Color convention (banker standard):
- 🔵 **Blue** = hardcoded input
- ⚫ **Black** = formula
- 🟢 **Green** = link to another sheet
- 🟡 **Yellow fill** = key assumption
- 🟢 **Green fill** = output

---

## Sources (all cited inline in the model)

- Tootsie Roll 10-K FY2025 (filed Feb 27, 2026): SEC EDGAR Accession 0001104659-26-021621
- 10Y UST yield: FRED DGS10, Apr 30, 2026 (~4.42%)
- Beta: CNBC, Yahoo Finance — 5Y monthly
- ERP: Damodaran 2026 implied ERP (~5.5%)
- Peer EV/EBITDA: GuruFocus, FinanceCharts.com, ValueInvesting.io (Apr 2026)
- Current share price: ~$42.10 (Apr 30, 2026, multiple sources confirmed)
